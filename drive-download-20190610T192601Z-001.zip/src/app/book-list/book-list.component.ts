import { Component, OnInit } from '@angular/core';
import { BookServiceService } from '../book-service.service';
import { Router } from '@angular/router';
import { Book } from '../book/book';
@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
//0. Create book object
book=new Book;
statusMessage:string;
books:Book[];

//1. Initialize the bookservice and Router
  constructor(private _bookService:BookServiceService) { }

  ngOnInit() {
    //List of Books
    this.getBooks();
  }

  getBooks():void
  {   console.log("Inside getBooks():::::")
      this._bookService.getAllBooks()
        //.subscribe((bookData) => this.books = bookData,
        .subscribe((x) => this.books = x,
        (error) =>{
            console.log(error);            
            this.statusMessage = "Problem with service. Please try again later!";
        }
        );
      console.log("end of  getBooks():::::");
    }
  }


