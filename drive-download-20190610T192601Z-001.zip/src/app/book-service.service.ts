import {Injectable } from '@angular/core';
import {Http,Response, Headers, RequestOptions} from '@angular/http';
import {Observable} from 'rxjs';
import { map } from 'rxjs/operators'; //Applies for 6 verison or above
import { catchError } from 'rxjs/operators'; 
import { Book } from './book/book';

@Injectable({
  providedIn: 'root'
})
export class BookServiceService {
  //4. Delete a  Book
  deleteBook(bookId: number){
    return this._httpService.delete("http://localhost:3000/books/"+bookId);
}
//3. Get  single book
getBookById(bookId: number): Observable<Book>{
  return this._httpService.get("http://localhost:3000/books/"+bookId)
          .pipe(map((response: Response) => response.json()))
          .pipe(catchError(this.handleError));
}

//1. Http service must be available with service creation
//--------------------List----------------
  constructor(private _httpService: Http) { }
getAllBooks(): Observable<Book[]>{
  return this._httpService.get("http://localhost:3000/books")
              .pipe(map((response: any) => response.json()))
              .pipe(catchError(this.handleError));
}
private handleError(error: Response){
  return Observable.throw(error);
}

//2....ADD a new book
addBook(book: Book){
  let body = JSON.parse(JSON.stringify(book));
  let headers = new Headers({ 'Content-Type': 'application/json' });
  let options = new RequestOptions({ headers: headers });
  if(book.id){    
    return this._httpService.put("http://localhost:3000/books/"+book.id, body, options);
    //return this._httpService.put("http://localhost:3000/posts", body, options);
      //return this._httpService.put("http://localhost:8037/spring-mvc-restfull-crud-example/book/"+book.bookid, body, options);
  }else{
      return this._httpService.post("http://localhost:3000/books", body, options);
  }
}
}// closing of bookservice
