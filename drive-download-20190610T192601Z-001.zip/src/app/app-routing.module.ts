import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';//Added
import { BookComponent } from './book/book.component';
import { BookListComponent } from './book-list/book-list.component';


const routes: Routes = [
  { path: 'Home', component: HomeComponent },// if getservletpath()=Home, forward to HomeComponent.ts
  { path: 'addBook', component: BookComponent },
  { path: 'books', component: BookListComponent }// if getservletpath()=Home, forward to HomeComponent.ts
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
