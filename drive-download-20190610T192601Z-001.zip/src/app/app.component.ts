import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'bookStore';
}

/**
 * . Angular 7.0.0 
2. Angular CLI 7.0.3 
3. TypeScript 3.1.1 
4. Node.js 10.3.0 
5. NPM 6.1.0 
6. RxJS 6.3.3 
7. In-Memory Web API 0.6.1
 */