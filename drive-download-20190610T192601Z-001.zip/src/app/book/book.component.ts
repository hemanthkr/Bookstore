import { Component, OnInit } from '@angular/core';
import { BookServiceService } from '../book-service.service';
import {Router} from '@angular/router';
import {Book} from '../book/book';
/** 1. Create a form book.component.html
 *  2. Add an add button in form which will call addBook() in Book.component.ts file.
*   3. addBook() will call addBook() of service which will cal spring rest call 
    4. Response from addBook() of service will display an object in console.
    5. call getBooks() to show updated data.
 * 
 */
@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  books:Book[]; //Create a book array
  statusMessage: string
  book = new Book();

  constructor(private _bookService:BookServiceService, private _router:Router) { }
  ngOnInit() {
    this.getBooks();
  }
//----------Delete----------
deleteBook(id:number)
{
  this._bookService.deleteBook(id)
  .subscribe((response) => {console.log(response); this.getBooks();},
  (error) =>{
      console.log(error);
      this.statusMessage = "Problem with service. Please try again later!";
  });
  this.reset();
  console.log("end of deleteBook():::::::");
}

//------------------Get A Book--------
  getBook(bookId: number){
    this._bookService.getBookById(bookId)
        .subscribe((bookData) => {this.book = bookData;
                                  this.getBooks(); 
                                 }),
        (error) => {
            console.log(error);
            this.statusMessage = "Problem with service. Please try again later!";
        }
    this.reset();    
}

//-------- Get All Books---------
  getBooks():void 
  {    console.log("Got a book");
      this._bookService.getAllBooks()
      .subscribe((bookData) => this.books = bookData,
                                (error) =>{console.log(error);
                                this.statusMessage = "Problem with service. Please try again later!";
                                
                                          }
                );
  }
//---------2. Add a book----------
addBook(): void{
               this._bookService.addBook(this.book)
               .subscribe((response) => {console.log(response); 
                this.getBooks();
               this.reset();
             },
           (error)=>{
              console.log(error);
              this.statusMessage = "Problem with service. Please try again later!";
            }
  );  
} 
  private reset(){
    this.book.id = null;
    this.book.title = null;
    this.book.author = null;
    this.book.price = null;
}

}// Closing of book component