import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; //need for bookadd form
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BookComponent } from './book/book.component';
import { BookListComponent } from './book-list/book-list.component';//Added
// After defining BookService
import { HttpModule } from '@angular/http';
import {BookServiceService} from './book-service.service';
import { Book } from './book/book';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BookComponent,
    BookListComponent  // added 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule
  ],
  providers: [BookServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
